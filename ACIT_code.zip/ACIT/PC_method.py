import numpy as np
import pandas as pd
import time
import torch
from itertools import combinations
from HSCIT import HSIC_naive, HSIC_lk, HSIC_lkw

# Setup device for computations
device = torch.device('cuda:0')

# Seed for reproducibility
seed = 22
np.random.seed(seed)
torch.manual_seed(seed)

def PC_HSIC_naive(data, maxCset):
    n = data.shape[1]
    skeleton = np.ones((n, n))
    np.fill_diagonal(skeleton, 0)

    for i in range(n - 1):
        for j in range(i + 1, n):
            continFlag = True
            for k in range(maxCset + 1):
                if skeleton[i, j] == 1 and continFlag:
                    if k == 0:
                        ind = HSIC_naive(data[:, i], data[:, j], np.array([]))
                        if ind:
                            skeleton[i, j] = 0
                            skeleton[j, i] = 0
                    else:
                        p1 = np.where(skeleton[i, :] == 1)[0]
                        p2 = np.where(skeleton[j, :] == 1)[0]
                        p3 = np.where(skeleton[:, i] == 1)[0]
                        p4 = np.where(skeleton[:, j] == 1)[0]
                        p = np.unique(np.setdiff1d(np.concatenate([p1, p2, p3, p4]), [i, j]))
                        if len(p) >= k:
                            csetM = list(combinations(p, k))
                        else:
                            break
                        for cset in csetM:
                            ind = HSIC_naive(data[:, i], data[:, j], data[:, cset])
                            if ind:
                                skeleton[i, j] = 0
                                skeleton[j, i] = 0
                                continFlag = False
                                break

    return skeleton

def PC_HSIC_lk(data, maxCset, device):
    n = data.shape[1]
    skeleton = np.ones((n, n))
    np.fill_diagonal(skeleton, 0)

    for i in range(n - 1):
        for j in range(i + 1, n):
            continFlag = True
            for k in range(maxCset + 1):
                if skeleton[i, j] == 1 and continFlag:
                    if k == 0:
                        ind = HSIC_lk(data[:, i], data[:, j], np.array([]), device)
                        if ind:
                            skeleton[i, j] = 0
                            skeleton[j, i] = 0
                    else:
                        p1 = np.where(skeleton[i, :] == 1)[0]
                        p2 = np.where(skeleton[j, :] == 1)[0]
                        p3 = np.where(skeleton[:, i] == 1)[0]
                        p4 = np.where(skeleton[:, j] == 1)[0]
                        p = np.unique(np.setdiff1d(np.concatenate([p1, p2, p3, p4]), [i, j]))
                        if len(p) >= k:
                            csetM = list(combinations(p, k))
                        else:
                            break
                        for cset in csetM:
                            ind = HSIC_lk(data[:, i], data[:, j], data[:, cset], device)
                            if ind:
                                skeleton[i, j] = 0
                                skeleton[j, i] = 0
                                continFlag = False
                                break

    return skeleton

def PC_HSIC_lkw(data, maxCset, device):
    n = data.shape[1]
    skeleton = np.ones((n, n))
    np.fill_diagonal(skeleton, 0)

    for i in range(n - 1):
        for j in range(i + 1, n):
            continFlag = True
            for k in range(maxCset + 1):
                if skeleton[i, j] == 1 and continFlag:
                    if k == 0:
                        ind = HSIC_lkw(data[:, i], data[:, j], np.array([]), device)
                        if ind:
                            skeleton[i, j] = 0
                            skeleton[j, i] = 0
                    else:
                        p1 = np.where(skeleton[i, :] == 1)[0]
                        p2 = np.where(skeleton[j, :] == 1)[0]
                        p3 = np.where(skeleton[:, i] == 1)[0]
                        p4 = np.where(skeleton[:, j] == 1)[0]
                        p = np.unique(np.setdiff1d(np.concatenate([p1, p2, p3, p4]), [i, j]))
                        if len(p) >= k:
                            csetM = list(combinations(p, k))
                        else:
                            break
                        for cset in csetM:
                            ind = HSIC_lkw(data[:, i], data[:, j], data[:, cset], device)
                            if ind:
                                skeleton[i, j] = 0
                                skeleton[j, i] = 0
                                continFlag = False
                                break

    return skeleton

def get_rpf(cskeleton, skeleton):
    R = np.sum(skeleton * cskeleton) / np.sum(skeleton)
    if np.sum(cskeleton) == 0:
        P = 0
    else:
        P = 2 * np.sum(skeleton * cskeleton) / np.sum(cskeleton)
    if R + P == 0:
        Score = [R, P, 0]
    else:
        Score = [R, P, 2 * R * P / (R + P)]
    return Score

def get_mean(rpfs_cell):
    # Convert all entries to numpy arrays if not already and compute the mean
    rpf_arr = np.array([np.array(rpf) for rpf in rpfs_cell])
    return np.mean(rpf_arr, axis=0)

def get_error_bar(rpfs_cell):
    # Convert all entries to numpy arrays if not already and compute the std error
    rpf_arr = np.array([np.array(rpf) for rpf in rpfs_cell])
    return np.std(rpf_arr, axis=0) / np.sqrt(rpf_arr.shape[0])


def gen4nodes(nsamples):
    n = 4
    skeleton = np.zeros((n, n))
    Acell = [None] * 7
    Bcell = [None] * 3
    Acell[0] = [1]
    Acell[1] = [2]
    Acell[2] = [3]
    Acell[3] = [1, 2]
    Acell[4] = [1, 3]
    Acell[5] = [2, 3]
    Acell[6] = [1, 2, 3]
    Bcell[0] = [2]
    Bcell[1] = [3]
    Bcell[2] = [2, 3]

    ch1 = np.random.permutation(7)[0]
    skeleton[0, Acell[ch1]] = 1
    ch2 = np.random.permutation(3)[0]
    skeleton[1, Bcell[ch2]] = 1

    if np.random.rand() > 0.5:
        skeleton[2, 3] = 1

    data = genData(skeleton, nsamples)
    return skeleton, data


def genData(skeleton, nsamples):
    dim = skeleton.shape[0]
    data = np.random.rand(nsamples, dim) * 2 - 1

    for k in range(dim):
        data[:, k] = data[:, k] - np.mean(data[:, k])

    for i in range(dim):
        parentidx = np.where(skeleton[:, i] == True)[0]
        parentidx = parentidx[parentidx != i]
        if parentidx.size > 0:
            pasample = np.zeros(nsamples)
            for w in parentidx:
                pasample += data[:, w] * (np.random.rand() * 0.8 + 0.2)
            n = (np.random.rand(nsamples) * 2 - 1) * 0.2
            n = n - np.mean(n)
            data[:, i] = pasample + n
    return data


def main():
    nsamples = [25, 50, 100, 200, 300, 400, 500, 600, 700, 800]
    consize = 2
    funcs = [PC_HSIC_naive, PC_HSIC_lk, PC_HSIC_lkw]
    Times = 100
    rpfs_Cell = []

    for T in range(Times):
        print(f"{Times - T}\n")
        rpfs = []
        for n in nsamples:
            skeleton, data = gen4nodes(n)
            rpf = []
            for func in funcs:
                start_time = time.time()
                if func == PC_HSIC_naive:
                    Cskeleton = func(data, consize)
                else:
                    Cskeleton = func(data, consize, device)
                tB = time.time() - start_time
                rpf.append(np.concatenate([get_rpf(Cskeleton, skeleton), [tB]]))
            rpfs.append(np.array(rpf).T)
        rpfs_Cell.append(np.hstack(rpfs))

    ave_rpfs = get_mean(rpfs_Cell)
    errorBar = get_error_bar(rpfs_Cell)

    ave_rpfs_new = ave_rpfs.T.reshape(-1, 4)
    errorBar_new = errorBar.T.reshape(-1, 4)

    try:
        print("ave_rpfs (重组后) =\n")
        print(ave_rpfs_new)

        print("\nerrorBar (重组后) =\n")
        print(errorBar_new)
    except IndexError as e:
        print(f"Index error occurred: {e}")


if __name__ == "__main__":
    main()