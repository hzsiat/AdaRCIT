import numpy as np
from itertools import combinations, permutations
import networkx as nx
import matplotlib.pyplot as plt
import time
import torch
from HSCIT import hsic_naive, hsic_lk, hsic_lkw
from evaluation import *

# Setup device for computations
device = torch.device('cuda:0')

# Seed for reproducibility
seed = 22
np.random.seed(seed)
torch.manual_seed(seed)


def sinedependence(n, d):
    X = np.random.uniform(-0.5, 0.5, (n, d))
    Z = np.random.uniform(-0.5, 0.5, n)
    Y1 = 20 * np.sin(4 * np.pi * X[:, 0] ** 2) + Z
    Y = Y1.reshape(-1, 1)
    return X, Y


def generate_cancer_network_data(n_samples, d):
    Pollution = np.random.uniform(0, 1, (n_samples, d))
    Smoker = np.random.uniform(0, 1, (n_samples, d))
    Cancer = Pollution @ np.random.uniform(0.2, 1, (d, d))\
             + Smoker @ np.random.uniform(0.2, 1, (d, d))\
             + np.random.uniform(-0.2, 0.2, (n_samples, d))
    nx, ny = sinedependence(n_samples, d)
    Xray = Cancer @ np.random.uniform(0.2, 1, (d, d)) + nx
    Dyspnoea = Cancer @ np.random.uniform(0.2, 1, (d, 1)) + ny
    return {
        'Pollution': Pollution,
        'Smoker': Smoker,
        'Cancer': Cancer,
        'Xray': Xray,
        'Dyspnoea': Dyspnoea
    }


def PC_alg(data, CItest_type, max_size, alpha, device=None):
    keys = list(data.keys())
    num_nodes = len(keys)

    # Create a fully connected undirected graph
    adj = np.ones((num_nodes, num_nodes), dtype=int) - np.eye(num_nodes, dtype=int)
    sep_set = [[list() for _ in range(num_nodes)] for _ in range(num_nodes)]

    # calc skeleton
    for l in range(max_size + 1):
        for i, j in permutations(range(num_nodes), 2):
            if adj[i][j] == 0:
                continue
            subsets = combinations([k for k in range(num_nodes) if k != i and k != j], l)
            for sep in subsets:
                if CItest_type == 'naive':
                    isCI = hsic_naive(data[keys[i]], data[keys[j]], [data[keys[s]] for s in sep])
                elif CItest_type == 'lk':
                    isCI = hsic_lk(data[keys[i]], data[keys[j]], [data[keys[s]] for s in sep], device)
                elif CItest_type == 'lkw':
                    isCI = hsic_lkw(data[keys[i]], data[keys[j]], [data[keys[s]] for s in sep], device)
                if isCI:
                    adj[i][j] = 0
                    adj[j][i] = 0
                    #sep_set[i][j].extend(sep)
                    #sep_set[j][i].extend(sep)
                    sep_set[i][j] += sep
                    break
        # identify V-structure
    for (i, j) in combinations(range(num_nodes), 2):
        if adj[i][j] != 1 or adj[j][i] != 1:
            continue
        for z in range(num_nodes):
            if i == z or j == z:
                continue
            if adj[i][z] != 0 or adj[z][i] != 0 or adj[j][z] != 1 or adj[z][j] != 1:
                adj[i][z] = adj[j][z] = 0

        # Orient the direction
    while True:
        change_bool = False

        for (x, y) in permutations(range(num_nodes), 2):  # Rule 1
            if not (adj[x][y] == 1 and adj[y][x] == 0):  # x -> y
                continue
            for z in set(range(num_nodes)) - set([x, y]):
                if not (adj[y][z] == 1 and adj[z][y] == 1):  # y -- z
                    continue
                if not (adj[x][z] == adj[z][x] == 0):  # x oo z (no edge between x and z)
                    continue
                adj[z][y] = 0  # y -> z
                change_bool = True
                break

        for (x, y) in permutations(range(num_nodes), 2):  # Rule 2
            if not (adj[x][y] == 1 and adj[y][x] == 0):  # x -> y
                continue
            for z in set(range(num_nodes)) - set([x, y]):
                if not (adj[y][z] == 1 and adj[z][y] == 0):  # y -> z
                    continue
                if not (adj[x][z] == adj[z][x] == 1):  # x -- z
                    continue
                adj[z][x] = 0  # x -> z
                change_bool = True
                break

        for (x, y) in permutations(range(num_nodes), 2):  # Rule 3
            if not (adj[x][y] == 1 and adj[y][x] == 1):  # x -- y
                continue
            set_zw = set(range(num_nodes)) - set([x, y])
            for (z, w) in combinations(set_zw, 2):
                if not (adj[z][y] == 1 and adj[y][z] == 0):  # z -> y
                    continue
                if not (adj[x][z] == adj[z][x] == 1):  # x -- z
                    continue
                if not (adj[w][y] == 1 and adj[y][w] == 0):  # w -> y
                    continue
                if not (adj[x][w] == adj[w][x] == 1):  # x -- w
                    continue
                adj[y][x] = 0  # x -> y
                change_bool = True
                break

        # for (x,y) in permutations(range(num_nodes),2):
        #     if not has_path(num_nodes, adj, x, y) :
        #         continue
        #     if not (adj[x][y]==1 and adj[y][x]==1):
        #         continue
        #     adj[y][x] = 0
        #     change_bool = True

        if change_bool == False:
            break

    return adj


def show_graph(num_nodes, adj_truth, adj_test):
    G_truth = nx.DiGraph()
    G_test = nx.DiGraph()
    for i in range(num_nodes):
        for j in range(num_nodes):
            if adj_truth[i][j] == 1:
                G_truth.add_edge(i, j)
    for i in range(num_nodes):
        for j in range(num_nodes):
            if adj_test[i][j] == 1:
                G_test.add_edge(i, j)
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    nx.draw(G_truth, with_labels=True, node_color='lightblue', font_weight='bold', node_size=700)
    plt.title('Ground Truth')
    plt.subplot(1, 2, 2)
    nx.draw(G_test, with_labels=True, node_color='lightgreen', font_weight='bold', node_size=700)
    plt.title('Predicted Structure')
    plt.show()


def train(nodes, true_G, num_nodes, num_samples, CItest_types, test_type, max_size, alpha, device):
    results = {}
    for CItest_type in CItest_types:
        print(f"Testing with CItest_type: {CItest_type}")
        adj_test = PC_alg(nodes, CItest_type, max_size, alpha, device)
        #adj_test[np.abs(adj_test) < alpha] = 0
        if test_type == 'skeleton':
            for (i, j) in combinations(range(num_nodes), 2):
                if adj_test[i][j] == 1 and adj_test[j][i] == 1:
                    adj_test[i][j] = -1
                    adj_test[j][i] = -1
        #print(adj_test)
        accuracy = count_accuracy(true_G, adj_test)
        results[f"{CItest_type}"] = accuracy
        print(f"Results for {CItest_type}: {accuracy}")
    return results


if __name__ == '__main__':
    test_type = 'skeleton'
    CItest_types = ['naive', 'lk', 'lkw']
    max_size = 1
    alpha = 0.05
    start = time.time()
    num_samples, d = 1000, 3
    nodes = generate_cancer_network_data(num_samples, d)

    true_G = np.array([[0, 0, 1, 0, 0],  # Pollution -> Cancer
                       [0, 0, 1, 0, 0],  # Smoker -> Cancer
                       [0, 0, 0, 1, 1],  # Cancer -> Xray, Dyspnoea
                       [0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0]])
    num_nodes = 5
    results = train(nodes, true_G, num_nodes, num_samples, CItest_types, test_type, max_size, alpha, device)
    end = time.time()
    print('Running time: %s Seconds' % (end - start))
