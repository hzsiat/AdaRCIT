import numpy as np
import math
import torch
import scipy.stats as st
from Test.hsic_naive import IndpTest_naive
from Test.hsic_lkgau import IndpTest_LKGaussian
from Test.hsic_lkwgau import IndpTest_LKWeightGaussian

device = torch.device('cuda:0')

import numpy as np
import torch

# Residual computation function
def res(x, z):
    zt = np.transpose(z)
    ztz_inv = np.linalg.inv(np.dot(zt, z))
    M = np.eye(x.shape[0]) - np.dot(z, np.dot(ztz_inv, zt))
    res = np.dot(M, x)
    return res

# Naive HSIC (Hilbert-Schmidt Independence Criterion) test
def hsic_naive(x, y, Z):
    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        # Combine multiple conditional variables into a matrix
        Z_combined = np.hstack([data for data in Z])
        X_res = torch.tensor(res(x, Z_combined))
        Y_res = torch.tensor(res(y, Z_combined))

    hsic = IndpTest_naive(X_res, Y_res, alpha=0.05, n_permutation=100, kernel_type="Gaussian", null_gamma=True)
    return hsic.perform_test()

# HSIC test using local kernel (LK) Gaussian
def hsic_lk(x, y, Z, device):
    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        # Combine multiple conditional variables into a matrix
        Z_combined = np.hstack([data for data in Z])
        X_res = torch.tensor(res(x, Z_combined))
        Y_res = torch.tensor(res(y, Z_combined))

    hsic = IndpTest_LKGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
    return hsic.perform_test()

# HSIC test using locally weighted kernel (LKW) Gaussian
def hsic_lkw(x, y, Z, device):
    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        # Combine multiple conditional variables into a matrix
        Z_combined = np.hstack([data for data in Z])
        X_res = torch.tensor(res(x, Z_combined))
        Y_res = torch.tensor(res(y, Z_combined))

    hsic = IndpTest_LKWeightGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
    return hsic.perform_test()
