from AIT.hsic_naive import IndpTest_naive
from AIT.hsic_lkgau import IndpTest_LKGaussian
from AIT.hsic_lkwgau import IndpTest_LKWeightGaussian
import numpy as np
import torch

'''

This code tests the Type  I error rates on the simulated data.

'''

# Set the random seed for reproducibility
seed = 22
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device('cuda:0')

# Function to generate dependent sine wave data
def sinedependence(n, d):
    X = np.random.uniform(-0.5, 0.5, (n, d))
    Z = np.random.uniform(-0.5, 0.5, n)
    Y1 = 20 * np.sin(4 * np.pi * (X[:, 0]**2)) + Z
    Y = Y1.reshape(-1, 1)
    return X, Y

# Function to compute residuals
def res(x, z):
    zt = np.transpose(z)
    ztz_inv = np.linalg.inv(np.dot(zt, z))
    M = np.eye(x.shape[0]) - np.dot(z, np.dot(ztz_inv, zt))
    res = np.dot(M, x)
    return res

# Function to generate data
def data(n, d):
    Z = np.random.uniform(0, 1, (n, d))
    a = np.random.uniform(0.2, 1, size=(d, d))
    b = np.random.uniform(0.2, 1, size=(d, 1))
    nx, ny = sinedependence(n, d)
    X = Z @ a
    Y = Z @ b

    nx_min = np.min(nx)
    nx_max = np.max(nx)
    ny_min = np.min(ny)
    ny_max = np.max(ny)
    X_min = np.min(X)
    X_max = np.max(X)
    Y_min = np.min(Y)
    Y_max = np.max(Y)

    # Normalize X and Y using both generated data and sine-dependent data
    X = X / (X_max - X_min) + nx / (nx_max - nx_min)
    Y = Y / (Y_max - Y_min) + ny / (ny_max - ny_min)

    return X, Y, Z

# Define sample sizes and number of tests
sample_sizes = [25, 50, 100, 200, 300, 400, 500]
test_num = 100
dimensions = [1, 2, 3, 4, 5]

# Initialize a dictionary to store results
results = {sample_size: np.zeros((3, len(dimensions))) for sample_size in sample_sizes}

# Calculate Type II error rate experiments
for sample_size in sample_sizes:
    for dim_idx, d in enumerate(dimensions):
        result_test_correct = np.zeros([3, test_num])

        for it in range(test_num):
            X, Y, Z = data(sample_size, d)
            residuals_X = res(X, Z)
            residuals_Y = res(Y, Z)
            X_res, Y_res = torch.tensor(residuals_X), torch.tensor(residuals_Y)

            # IndpTest_naive
            hsic0 = IndpTest_naive(X_res, Y_res, alpha=0.05, n_permutation=100, kernel_type="Gaussian", null_gamma=True)
            results_all0 = hsic0.perform_test()
            result_test_correct[0, it] = float(results_all0['h0_norejected'])

            # IndpTest_LKGaussian
            hsic1 = IndpTest_LKGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
            results_all1 = hsic1.perform_test(debug=-1, if_grid_search=True)
            result_test_correct[1, it] = float(results_all1['h0_norejected'])

            # IndpTest_LKWeightGaussian
            hsic2 = IndpTest_LKWeightGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
            results_all2 = hsic2.perform_test(debug=-1, if_grid_search=True)
            result_test_correct[2, it] = float(results_all2['h0_norejected'])

        final_results = np.mean(result_test_correct, axis=1)
        results[sample_size][:[:, dim_idx] = final_results

    # Print results
    print(f'Results for sample size {sample_size}')
    print(results[sample_size])
