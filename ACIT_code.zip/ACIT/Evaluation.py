from itertools import combinations, permutations
import numpy as np

def count_accuracy(B_true, B_est):
    """Compute various accuracy metrics for B_est.

    true positive = predicted association exists in the condition in the correct direction
    reverse = predicted association exists in the condition in the opposite direction
    false positive = predicted association does not exist in the condition

    Args:
        B_true (np.ndarray): [d, d] ground truth graph, {0, 1}
        B_est (np.ndarray): [d, d] estimate, {0, 1, -1}, -1 is undirected edge in CPDAG

    Returns:
        fdr: (reverse + false positive) / prediction positive
        tpr: (true positive) / condition positive
        fpr: (reverse + false positive) / condition negative
        shd: undirected extra + undirected missing + reverse
        nnz: prediction positive
    """
    '''
    if (B_est == -1).any():  # CPDAG case
        if not ((B_est == 0) | (B_est == 1) | (B_est == -1)).all():
            raise ValueError('B_est should take values in {0,1,-1}')
        if ((B_est == -1) & (B_est.T == -1)).any():
            raise ValueError('undirected edge should only appear once')
    else:  # DAG case
        if not ((B_est == 0) | (B_est == 1)).all():
            raise ValueError('B_est should take values in {0,1}')
        if not is_dag(B_est):
            raise ValueError('B_est should be a DAG')
    '''
    d = B_true.shape[0]
    # Linear index of nonzeros
    pred_und = np.flatnonzero(B_est == -1)  # Predicted undirected edges
    pred = np.flatnonzero(B_est == 1)  # Predicted directed edges

    cond = np.flatnonzero(B_true)  # True directed edges
    cond_reversed = np.flatnonzero(B_true.T)
    cond_skeleton = np.concatenate([cond, cond_reversed])  # True skeleton (all edges)
    
    # True positives
    true_pos = np.intersect1d(pred, cond, assume_unique=True)  # Correctly predicted directed edges
    # Treat undirected edges favorably
    true_pos_und = np.intersect1d(pred_und, cond_skeleton, assume_unique=True)  # Correctly predicted undirected edges
    true_pos = np.concatenate([true_pos, true_pos_und])  # All correctly predicted edges (directed + undirected)
    
    # False positives
    false_pos = np.setdiff1d(pred, cond_skeleton, assume_unique=True)  # Incorrectly predicted directed edges
    false_pos_und = np.setdiff1d(pred_und, cond_skeleton, assume_unique=True)  # Incorrectly predicted undirected edges
    false_pos = np.concatenate([false_pos, false_pos_und])  # All incorrectly predicted edges
    
    # Reversed edges
    extra = np.setdiff1d(pred, cond, assume_unique=True) 
    reverse = np.intersect1d(extra, cond_reversed, assume_unique=True)  # Incorrectly predicted directed edges (wrong direction)
    
    # Compute ratios
    pred_size = len(pred) + len(pred_und)  # Total number of predicted edges
    cond_neg_size = 0.5 * d * (d - 1) - len(cond) 
    Precision = 1 - float(len(reverse) + len(false_pos)) / max(pred_size, 1)  # Precision
    Recall = float(len(true_pos)) / max(len(cond), 1)  # Recall (correctly predicted edges / total correct edges)
    F1_Score = 2 * (Precision * Recall) / (Precision + Recall)
    # fpr = float(len(reverse) + len(false_pos)) / max(cond_neg_size, 1)  # False positive rate (incorrect predictions / total negatives)
    
    # Structural Hamming Distance
    pred_lower = np.flatnonzero(np.tril(B_est + B_est.T))
    cond_lower = np.flatnonzero(np.tril(B_true + B_true.T))
    extra_lower = np.setdiff1d(pred_lower, cond_lower, assume_unique=True)
    missing_lower = np.setdiff1d(cond_lower, pred_lower, assume_unique=True)
    shd = len(extra_lower) + len(missing_lower) + len(reverse)
    
    return {'Precision': Precision, 'Recall': Recall, 'F1_Score': F1_Score, 'shd': shd, 'nnz': pred_size}
