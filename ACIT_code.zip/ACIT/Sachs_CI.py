import numpy as np
import pandas as pd
import time
import torch
from Test.naive import IndpTest_naive
from Test.lkgau import IndpTest_LKGaussian
from Test.lkwgau import IndpTest_LKWeightGaussian

device = torch.device('cuda:0')

'''

This code tests the Type I and Type II error rates on the Sachs Dataset.

'''

# Load the processed dataset and independence table
data = pd.read_csv('data_processed.csv', delimiter=',', header=None).values
ind_table = pd.read_csv('ind_table.csv', delimiter=',', header=None).values

# Function to calculate residuals
def res(x, z):
    zt = np.transpose(z)
    ztz_inv = np.linalg.inv(np.dot(zt, z))
    M = np.eye(x.shape[0]) - np.dot(z, np.dot(ztz_inv, zt))
    res = np.dot(M, x)
    return res

# Function to perform HSIC naive test
def HSIC_naive(x, y, Z):
    x = x.reshape(-1, 1)
    y = y.reshape(-1, 1)

    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        X_res = torch.tensor(res(x, Z))
        Y_res = torch.tensor(res(y, Z))

    hsic = IndpTest_naive(X_res, Y_res, alpha=0.05, n_permutation=100, kernel_type="Gaussian", null_gamma=True)
    return hsic.perform_test()

# Function to perform HSIC LK Gaussian test
def HSIC_lk(x, y, Z, device):
    x = x.reshape(-1, 1)
    y = y.reshape(-1, 1)

    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        X_res = torch.tensor(res(x, Z))
        Y_res = torch.tensor(res(y, Z))

    hsic = IndpTest_LKGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
    return hsic.perform_test()

# Function to perform HSIC LK Weight Gaussian test
def HSIC_lkw(x, y, Z, device):
    x = x.reshape(-1, 1)
    y = y.reshape(-1, 1)

    if len(Z) == 0:
        X_res, Y_res = torch.tensor(x), torch.tensor(y)
    else:
        X_res = torch.tensor(res(x, Z))
        Y_res = torch.tensor(res(y, Z))

    hsic = IndpTest_LKWeightGaussian(X_res, Y_res, device, alpha=0.05, n_permutation=100, null_gamma=True, split_ratio=0.5)
    return hsic.perform_test()

# Function to check the independence in the main program
def ind_check(data, d, alg_func):
    n = d.shape[0]
    ind_num = np.sum(d[:, 2])  # Column 3 represents the independence judgment
    nonind_num = n - ind_num
    temp1 = 0
    temp2 = 0

    for i in range(n):
        x = data[:, d[i, 0] - 1] 
        y = data[:, d[i, 1] - 1]

        # Pass parameters based on the function signature
        if alg_func.__name__ in ['HSIC_lk', 'HSIC_lkw']:
            ind = alg_func(x, y, [], device)
        else:
            ind = alg_func(x, y, [])

        if ind != d[i, 2]:  # If the prediction result does not match the expectation
            if d[i, 2] == 1:
                temp1 += 1
            else:
                temp2 += 1

    a = temp1 / ind_num
    b = temp2 / nonind_num
    rpf = [a, b, np.mean([a, b])]
    return rpf

# Function to test the algorithms
def test_algorithms(data, ind_table, algM, times=100):
    score_list = []

    for T in range(times):
        np.random.seed(T)
        print(f"Running iteration {T + 1}/{times}")
        scores = []
        for alg_func in algM:
            rpf = ind_check(data, ind_table, alg_func)
            scores.append(rpf)
        score_list.append(scores)

    mean_scores = np.mean(score_list, axis=0)
    error_bars = np.std(score_list, axis=0) / np.sqrt(times)

    print("Mean Scores: ", mean_scores)
    print("Error Bars: ", error_bars)

    return mean_scores, error_bars

# Main program
if __name__ == "__main__":
    start_time = time.time()

    # Define the list of algorithms
    algM = [HSIC_naive, HSIC_lk, HSIC_lkw]

    # Run the tests
    mean_scores, error_bars = test_algorithms(data, ind_table, algM, times=100)

    end_time = time.time()
    print('Running time: %s Seconds' % (end_time - start_time))
