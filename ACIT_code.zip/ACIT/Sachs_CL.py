import pandas as pd
import numpy as np
import time
from PC_method import PC_HSIC_naive, PC_HSIC_lk, PC_HSIC_lkw
import torch

device = torch.device('cuda:0')

'''

This code tests the Recall, Precision, and F1-Score on the Sachs Dataset.

'''

# Load the data
data = pd.read_csv('data_processed.csv', delimiter=',', header=None).values
skeleton = pd.read_csv('skeleton_sachs.csv', delimiter=',', header=None).values

# Function to calculate Recall, Precision, and F1-Score
def getRPF(cskeleton, skeleton):
    R = np.sum(skeleton * cskeleton) / np.sum(skeleton)  # Recall
    if np.sum(cskeleton) == 0:
        P = 0
    else:
        P = 2 * np.sum(skeleton * cskeleton) / np.sum(cskeleton)  # Precision
    if R + P == 0:
        Score = [R, P, 0]
    else:
        Score = [R, P, 2 * R * P / (R + P)]  # F1-Score
    return Score

# Initialize parameters
algM = [PC_HSIC_naive, PC_HSIC_lk, PC_HSIC_lkw]
iterations = 1
conSize = 2  # Size of the conditional set
scoreCell = []
scoreM = None

# Start timing
start_time = time.time()

for T in range(1, iterations + 1):
    print("Iteration:", T)
    score = []

    for alg in algM:
        if alg.__name__ == "PC_HSIC_naive":
            Cskeleton = alg(data, conSize)
        elif alg.__name__ == "PC_HSIC_lk":
            Cskeleton = alg(data, conSize, device)
        elif alg.__name__ == "PC_HSIC_lkw":
            Cskeleton = alg(data, conSize, device)
        else:
            raise ValueError("Unknown algorithm")

        rpf = getRPF(Cskeleton, skeleton)  # Calculate RPF values
        score.append(rpf)

    scoreCell.append(np.array(score))  # Store for error bar calculation

    if T == 1:
        scoreM = np.zeros_like(scoreCell[0])

    scoreM += scoreCell[-1]
    print("Average Score:", scoreM / T)  # Output average score

    # Time elapsed for each iteration
    print("Elapsed time:", time.time() - start_time)

print("Total elapsed time:", time.time() - start_time)
